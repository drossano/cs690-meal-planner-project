﻿namespace MealPlanner;


class Program
{
    static void Main(string[] args)
    {
        ConsoleUI theUI = new();
        theUI.Show();
    }

}